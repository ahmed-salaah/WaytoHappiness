//
//  NotificationManager.h
//  WayToHappiness
//
//  Created by Mohamed Abd El-latef on 4/1/14.
//  Copyright (c) 2014 Mohamed Abd El-latef. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NotificationManager : NSObject

+ (NotificationManager *) sharedNotificationManager;
- (void) schueduleNotification;
@end
